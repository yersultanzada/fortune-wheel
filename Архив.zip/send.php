<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $hash = $_POST["hash"];
    $lead = $_POST["lead"];
    $bonus = $_POST["bonus"];
    // другие данные, которые вы хотите отправить

    // Далее код для отправки письма на почту с использованием этих данных
    // Например, с помощью функции mail() в PHP

    // Пример отправки письма
    $to = "yersultan.zada@gmail.com";
    $subject = "Новая заявка";
    $message = "Hash: $hash\nLead: $lead\nBonus: $bonus\n";
    // другие данные, которые вы хотите отправить

    $headers = "From: yersultan.zada@gmail.com";

    mail($to, $subject, $message, $headers);

    // Далее вы можете добавить любую логику обработки данных, если нужно
}
?>
